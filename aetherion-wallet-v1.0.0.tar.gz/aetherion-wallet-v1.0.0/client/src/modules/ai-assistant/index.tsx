// AI Assistant Module
import React from 'react';
import ChatInterface from './components/ChatInterface';

export {
  ChatInterface
};