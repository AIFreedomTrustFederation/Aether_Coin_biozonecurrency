import React from 'react';
import Bridge from '../components/bridge/Bridge';

const BridgePage = () => {
  return <Bridge />;
};

export default BridgePage;