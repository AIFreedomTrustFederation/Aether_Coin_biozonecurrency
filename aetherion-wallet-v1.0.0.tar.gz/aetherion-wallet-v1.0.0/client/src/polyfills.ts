// Polyfills.ts is now empty
// All polyfills have been moved to main.tsx to ensure they're loaded before any other code